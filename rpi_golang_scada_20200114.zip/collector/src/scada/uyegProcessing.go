package main

import (
	"fmt"
	//"log"
	"math"
	//"os"
	"scada/uyeg"
	"strings"
	"time"
)

// UYeGProcessing 함수는 수집된 데이터를 정제, 처리하는 함수
func UYeGProcessing(client *uyeg.ModbusClient, collChan <-chan map[string]interface{}, tfChan chan<- []interface{}) {

	//	syncMap := SyncMap{v: make(map[string]interface{})}
	//	var preTime =""
	//ticker := time.NewTicker(500 * time.Millisecond)
	//ds := make([]interface{}, 0, 100)   // 미리 공간 할당해둠1
	//var lastData map[string]interface{} // 미리 공간 할당해둠2

	var queue ItemQueue
	if queue.items == nil {
		queue = ItemQueue{}
		queue.New()
	}

	//var queue *Queue = New()
	go QueueProcess(client, &queue, tfChan)

	for {
		select {
		case <-client.Done2:
			fmt.Println(fmt.Sprintf("=> %s (%s:%d) 데이터 처리 종료", client.Device.MacId, client.Device.Host, client.Device.Port))
			return
		case data := <-collChan:
			queue.Enqueue(data)
			/*	fmt.Println(" No Data ", t)
				fpLog, _ := os.OpenFile(client.Device.MacId+"_logfile.txt", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
				logFile := log.New(fpLog, "", log.Ldate|log.Ltime|log.Lshortfile)
				logFile.Printf(" No Data %s \r\n", t)
				fpLog.Close()
			*/
			/*
				default:
					fmt.Println("no message received")
			*/
		}
		time.Sleep(1 * time.Millisecond)
	}
}

func QueueProcess(client *uyeg.ModbusClient, queue *ItemQueue, tfChan chan<- []interface{}) {
	syncMap := SyncMap{v: make(map[string]interface{})}
	ds := make([]interface{}, 0, 100)   // 미리 공간 할당해둠1
	var lastData map[string]interface{} // 미리 공간 할당해둠2

	//var preTime  *string = new(string)

	for {
		for len(queue.items) > 0 {
			data := (*queue).Dequeue()
			//fmt.Println("Dequeue value :", (*data).(map[string]interface{})["time"])
			//fmt.Println("Dequeue value :", data.(map[string]interface{})["time"])

			t := (*data).(map[string]interface{})["time"].(time.Time).Truncate(time.Duration(client.Device.ProcessInterval) * time.Millisecond).Format(TimeFormat)
			if client.Device.MacId == "21000000002D" {
				fmt.Println(time.Now(), "Mac:", client.Device.MacId, " time:[", t, "] ", " dataTime:", (*data).(map[string]interface{})["time"])
			}

			if v := syncMap.Get(t); v != nil { // 데이터가 있는경우

				tv := make(map[string]interface{})
				for k, v := range v.(map[string]interface{}) {
					var tmp float64
					if strings.Contains(k, "time") {
						tv[k] = v
						continue
					} else if strings.Contains(k, "Volt") {
						tmp = math.Min(v.(float64), (*data).(map[string]interface{})[k].(float64))
					} else {
						tmp = math.Max(v.(float64), (*data).(map[string]interface{})[k].(float64))
					}
					tv[k] = tmp
				}
				syncMap.Set(t, tv)
				
				//}
			} else {

				(*data).(map[string]interface{})["time"] = t
				syncMap.Set(t, (*data).(map[string]interface{}))
				

				tmillisecond := t[len(t)-4:]
				t2, _ := time.Parse(TimeFormat[:len(TimeFormat)-4], t)
				//fmt.Println("nowtime : ", t, "tmillisecond: ", tmillisecond, ", t2:", t2, ", len(syncMap) = ", syncMap.Size())
				if tmillisecond == ".000" && syncMap.Size() >= 10 {
					sMap := syncMap.GetMap()
					bSecT, _ := time.Parse(TimeFormat[:len(TimeFormat)-4], t2.Add(-1 * time.Second).Format(TimeFormat)[:len(TimeFormat)-4])
					//	fmt.Println("nowtime : ", t, "t2: ", t2, "bSecT: ", bSecT)

					// .000 부터 데이터 비교.
					noData := false
					for i := 0; i < 1000/client.Device.ProcessInterval; i++ {
						vT := bSecT.Add(time.Duration(i*client.Device.ProcessInterval) * time.Millisecond).Format(TimeFormat)
						if val, exists := sMap[vT]; exists == true { // 데이터가 있는 경우.
							value := val.(map[string]interface{})
							value["status"] = true
							ds = append(ds, value)
							lastData = val.(map[string]interface{}) // 마지막 데이터를 초기화 시킨다.
							syncMap.Delete(vT)                      // 추가한 데이터는 삭제한다.
						} else { // 데이터가 없는 경우.
							if lastData != nil {
								ld := CopyMap(lastData)
								ld["time"] = bSecT.Format(TimeFormat)
								ld["status"] = false
								ds = append(ds, ld)
							}
							fmt.Println(" No Data ", vT)
							/*
							fpLog, _ := os.OpenFile(client.Device.MacId+"_logfile.txt", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
							logFile := log.New(fpLog, "", log.Ldate|log.Ltime|log.Lshortfile)
							logFile.Printf(" No Data %s \r\n", vT)
							fpLog.Close()
							*/
							noData = true
						}
					}
					if noData == false {
						tfChan <- ds
						ds = ds[:0] // 데이터 삭제
					}
				}
			}
			//fmt.Println(time.Now())
			time.Sleep(1 * time.Millisecond)
		}
		time.Sleep(1 * time.Millisecond)
	}
}

/*
func QueueProcess(client *uyeg.ModbusClient, queue *ItemQueue, tfChan chan<- []interface{}) {
//	syncMap := SyncMap{v: make(map[string]interface{})}
	//ticker := time.NewTicker(500 * time.Millisecond)
	//ds := make([]interface{}, 0, 100)   // 미리 공간 할당해둠1
	//var lastData map[string]interface{} // 미리 공간 할당해둠2

	for {
		for len(queue.items) > 0 {
			data := (*queue).Dequeue()
			fmt.Println("Dequeue value :", (*data).(map[string]interface{})["time"])
			//fmt.Println("Dequeue value :", data.(map[string]interface{})["time"])

			t := (*data).(map[string]interface{})["time"].(time.Time).Truncate(time.Duration(client.Device.ProcessInterval) * time.Millisecond).Format(TimeFormat)

			if v := syncMap.Get(t); v != nil { // 데이터가 있는경우

				tv := make(map[string]interface{})

				for k, v := range v.(map[string]interface{}) {
					var tmp float64

					if strings.Contains(k, "time") {
						tv[k] = v
						continue
					} else if strings.Contains(k, "Volt") {
						tmp = math.Min(v.(float64), (*data).(map[string]interface{})[k].(float64))
					} else {
						tmp = math.Max(v.(float64), (*data).(map[string]interface{})[k].(float64))
					}

					tv[k] = tmp
				}
				syncMap.Set(t, tv)

			} else { // 데이터가 없는 경우
				(*data).(map[string]interface{})["time"] = t
				syncMap.Set(t, (*data).(map[string]interface{}))
				tmillisecond := t[len(t)-4:]
				t2, _ := time.Parse(TimeFormat[:len(TimeFormat)-4], t)
				//fmt.Println("nowtime : ", t, "tmillisecond: ", tmillisecond, ", t2:", t2, ", len(syncMap) = ", syncMap.Size())
				if tmillisecond == ".000" && syncMap.Size() >= 10 {
					sMap := syncMap.GetMap()
					bSecT, _ := time.Parse(TimeFormat[:len(TimeFormat)-4], t2.Add(-1 * time.Second).Format(TimeFormat)[:len(TimeFormat)-4])
					//	fmt.Println("nowtime : ", t, "t2: ", t2, "bSecT: ", bSecT)

					// .000 부터 데이터 비교.
					noData := false
					for i := 0; i < 1000/client.Device.ProcessInterval; i++ {
						vT := bSecT.Add(time.Duration(i*client.Device.ProcessInterval) * time.Millisecond).Format(TimeFormat)
						if val, exists := sMap[vT]; exists == true { // 데이터가 있는 경우.
							value := val.(map[string]interface{})
							value["status"] = true
							ds = append(ds, value)
							lastData = val.(map[string]interface{}) // 마지막 데이터를 초기화 시킨다.
							syncMap.Delete(vT)                      // 추가한 데이터는 삭제한다.
						} else { // 데이터가 없는 경우.
							if lastData != nil {
								ld := CopyMap(lastData)
								ld["time"] = bSecT.Format(TimeFormat)
								ld["status"] = false
								ds = append(ds, ld)
							}
							fmt.Println(" No Data ", vT)
							fpLog, _ := os.OpenFile(client.Device.MacId+"_logfile.txt", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
							logFile := log.New(fpLog, "", log.Ldate|log.Ltime|log.Lshortfile)
							logFile.Printf(" No Data %s \r\n", vT)
							fpLog.Close()
							noData = true
						}
					}
					if noData == false {
						tfChan <- ds
						ds = ds[:0] // 데이터 삭제
					}
				}
			}


		}
		time.Sleep(1 * time.Millisecond)

	}

}
*/
