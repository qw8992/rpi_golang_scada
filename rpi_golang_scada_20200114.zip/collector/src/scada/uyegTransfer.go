package main

import (
	"fmt"
	//"log"
	//"os"
	"scada/uyeg"
)

func UYeGTransfer(client *uyeg.ModbusClient, tfChan <-chan []interface{}) {
	for {
		select {
		case <-client.Done3:
			fmt.Println(fmt.Sprintf("=> %s (%s:%d) 데이터 전송 종료", client.Device.MacId, client.Device.Host, client.Device.Port))
			return
		case data := <-tfChan:
			d := data[0].(map[string]interface{})
			if t, exists := d["time"]; exists {
				bSecT := t.(string)[:len(TimeFormat)-4]
				jsonBytes := client.GetRemapJson(bSecT, data)
				SendRequest(GetCompressedString(jsonBytes))
				//s := string(jsonBytes)
				/*
				fpLog, _ := os.OpenFile(client.Device.MacId+"_senddata.txt", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
				logFile := log.New(fpLog, "", log.Ldate|log.Ltime|log.Lshortfile)
				logFile.Printf("Mac %s send time %s \r\n", client.Device.MacId, t)
				fpLog.Close()
				*/
				
				fmt.Println("Mac ", client.Device.MacId, " send Time:", t)
			}
		}
	}
}
