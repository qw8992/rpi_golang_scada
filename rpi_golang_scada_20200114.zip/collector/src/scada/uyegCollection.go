package main

import (
	"fmt"
//	"log"
//	"os"
	"scada/uyeg"
	"time"
)

// UYeGDataCollection 함수는 데이터를 수집하는 함수입니다
func UYeGDataCollection(client *uyeg.ModbusClient, collChan chan<- map[string]interface{}) {
	var errCount, errCountConn = 0, 0
	ticker := time.NewTicker(10 * time.Millisecond)

	for {
		select {
		case <-client.Done1:
			fmt.Println(fmt.Sprintf("=> %s (%s:%d) 데이터 수집 종료", client.Device.MacId, client.Device.Host, client.Device.Port))
			return
		case t := <-ticker.C:

			/*
			fpLog, _ := os.OpenFile(client.Device.MacId+"_"+fmt.Sprintf("%d-%02d-%2d", t.Year(), t.Month(), t.Day())+"_request_rawdata.txt", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
			logFile := log.New(fpLog, "", log.Ldate|log.Ltime|log.Lshortfile)
			logFile.Printf("time %s 요청함.\r\n", t)
			fpLog.Close()
*/
			readData := client.GetReadHoldingRegisters()
/*
			fpLog, _ = os.OpenFile(client.Device.MacId+"_"+fmt.Sprintf("%d-%02d-%2d", t.Year(), t.Month(), t.Day())+"_received_rawdata.txt", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
			logFile = log.New(fpLog, "", log.Ldate|log.Ltime|log.Lshortfile)
			logFile.Printf("Mac %s time %s Data: %s \r\n", client.Device.MacId, t, readData)
			fpLog.Close()
*/
			fmt.Println(t, client.Device.MacId, " 요청함.")
			if readData == nil {
				//test:= readData;
				ticker.Stop()
				errCount = errCount + 1
				fmt.Println(time.Now().In(Loc).Format(TimeFormat), fmt.Sprintf("Failed to read data Try again (%s:%d)..", client.Device.Host, client.Device.Port))
				if errCount > client.Device.RetryCount {
					client.Handler.Close()
					if client.Connect() {
						fmt.Println(time.Now().In(Loc).Format(TimeFormat), fmt.Sprintf("Succeded to reconnect the connection.. (%s:%d)..", client.Device.Host, client.Device.Port))
						errCount = 0
					} else {
						fmt.Println(time.Now().In(Loc).Format(TimeFormat), fmt.Sprintf("Failed to reconnect the connection.. (%s:%d)..", client.Device.Host, client.Device.Port))
						errCountConn = errCountConn + 1

						if errCountConn > client.Device.RetryConnFailedCount {
							derr := make(map[string]interface{})
							derr["Device"] = client.Device
							derr["Error"] = fmt.Sprintf("%s(%s): Connection failed..", client.Device.Name, client.Device.MacId)
							derr["Restart"] = false

							ErrChan <- derr
						}
					}
				}
				time.Sleep(time.Duration(client.Device.RetryCycle) * time.Millisecond)
				ticker = time.NewTicker(10 * time.Millisecond)
				continue
			} else {
				errCount = 0
			}

			collChan <- readData

			/*
				default:

					//fmt.Println(time.Now().In(Loc).Format(TimeFormat), request)
					readData := client.GetReadHoldingRegisters()
					fmt.Println(time.Now().In(Loc).Format(TimeFormat), " 요청함.")
					if readData == nil {
						errCount = errCount + 1
						fmt.Println(time.Now().In(Loc).Format(TimeFormat), fmt.Sprintf("Failed to read data Try again (%s:%d)..", client.Device.Host, client.Device.Port))
						if errCount > client.Device.RetryCount {
							client.Handler.Close()
							if client.Connect() {
								fmt.Println(time.Now().In(Loc).Format(TimeFormat), fmt.Sprintf("Succeded to reconnect the connection.. (%s:%d)..", client.Device.Host, client.Device.Port))
								errCount = 0
							} else {
								fmt.Println(time.Now().In(Loc).Format(TimeFormat), fmt.Sprintf("Failed to reconnect the connection.. (%s:%d)..", client.Device.Host, client.Device.Port))
								errCountConn = errCountConn + 1

								if errCountConn > client.Device.RetryConnFailedCount {
									derr := make(map[string]interface{})
									derr["Device"] = client.Device
									derr["Error"] = fmt.Sprintf("%s(%s): Connection failed..", client.Device.Name, client.Device.MacId)
									derr["Restart"] = false

									ErrChan <- derr
								}
							}
						}
						time.Sleep(time.Duration(client.Device.RetryCycle) * time.Millisecond)
						continue
					} else {
						errCount = 0
					}
					collChan <- readData
					time.Sleep(30 * time.Millisecond)
			*/
		}
	}
}
